import React from "react";

function Header() {

  return (
    <header className="header">

      <h2>Farm Employee Management</h2>

      <p>Employee Directory System</p>

    </header>
  );
}

export default Header;