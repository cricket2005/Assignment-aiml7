import React, { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate
} from "react-router-dom";

import Navbar from "./components/Navbar";

import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/Tasks";
import AddTask from "./pages/AddTask";
import TaskDetails from "./pages/TaskDetails";
import CompletedTasks from "./pages/CompletedTasks";

import ProtectedRoute from "./ProtectedRoute";

import "./App.css";

function App() {

  const [tasks, setTasks] = useState([
    {
      id: 1,
      header: "Complete React Assignment",
      description: "Complete Task Manager assignment using React Router.",
      priority: "High",
      category: "Academic",
      raisedDate: new Date().toLocaleString(),
      dueDate: "28 Aug 2026",
      status: "Pending"
    },
    {
      id: 2,
      header: "Buy Groceries",
      description: "Purchase vegetables and other grocery items.",
      priority: "Medium",
      category: "Personal",
      raisedDate: new Date().toLocaleString(),
      dueDate: "28 Aug 2026",
      status: "Raised"
    }
  ]);

  const [isLoggedIn, setIsLoggedIn] = useState(true);

  // Add Task
  const addTask = (task) => {
    const newTask = {
      ...task,
      id: Date.now(),
      raisedDate: new Date().toLocaleString(),
      dueDate: "28 Aug 2026"
    };

    setTasks([...tasks, newTask]);
  };

  // Delete Task
  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  // Complete Task
  const completeTask = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id
          ? { ...task, status: "Closed" }
          : task
      )
    );
  };

  // Update Task
  const updateTask = (updatedTask) => {
    setTasks(
      tasks.map((task) =>
        task.id === updatedTask.id
          ? updatedTask
          : task
      )
    );
  };

  return (
    <BrowserRouter>

      <Navbar
        isLoggedIn={isLoggedIn}
        setIsLoggedIn={setIsLoggedIn}
      />

      <Routes>

        <Route
          path="/"
          element={<Navigate to="/dashboard" />}
        />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Dashboard tasks={tasks} />
            </ProtectedRoute>
          }
        />

        <Route
          path="/tasks"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Tasks
                tasks={tasks}
                deleteTask={deleteTask}
                completeTask={completeTask}
              />
            </ProtectedRoute>
          }
        />

        <Route
          path="/add-task"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <AddTask addTask={addTask} />
            </ProtectedRoute>
          }
        />

        <Route
          path="/task/:id"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <TaskDetails
                tasks={tasks}
                updateTask={updateTask}
                deleteTask={deleteTask}
              />
            </ProtectedRoute>
          }
        />

        <Route
          path="/completed"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <CompletedTasks tasks={tasks} />
            </ProtectedRoute>
          }
        />

        <Route
          path="*"
          element={<h2>404 - Page Not Found</h2>}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;