import React, { useState } from "react";
import {
  useParams,
  useNavigate
} from "react-router-dom";

function TaskDetails({
  tasks,
  updateTask,
  deleteTask
}) {

  const { id } = useParams();

  const navigate = useNavigate();

  const task = tasks.find(
    (item) => item.id.toString() === id
  );

  const [editMode, setEditMode] = useState(false);

  const [header, setHeader] = useState(
    task ? task.header : ""
  );

  const [description, setDescription] = useState(
    task ? task.description : ""
  );

  const [priority, setPriority] = useState(
    task ? task.priority : "Medium"
  );

  if (!task) {
    return (
      <div className="container">
        <h2>Task Not Found</h2>
      </div>
    );
  }

  const saveChanges = () => {

    updateTask({
      ...task,
      header,
      description,
      priority
    });

    setEditMode(false);
  };

  const removeTask = () => {

    deleteTask(task.id);

    navigate("/tasks");
  };

  return (
    <div className="container">

      <h1>Task Details</h1>

      {editMode ? (

        <div>

          <label>Task Header</label>

          <input
            value={header}
            onChange={(e) =>
              setHeader(e.target.value)
            }
          />

          <label>Description</label>

          <textarea
            value={description}
            onChange={(e) =>
              setDescription(e.target.value)
            }
          />

          <label>Priority</label>

          <select
            value={priority}
            onChange={(e) =>
              setPriority(e.target.value)
            }
          >
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>

          <button onClick={saveChanges}>
            Save Changes
          </button>

          <button onClick={() => setEditMode(false)}>
            Cancel
          </button>

        </div>

      ) : (

        <div className="task-card">

          <h2>{task.header}</h2>

          <p>
            <b>Description:</b> {task.description}
          </p>

          <p>
            <b>Priority:</b> {task.priority}
          </p>

          <p>
            <b>Category:</b> {task.category}
          </p>

          <p>
            <b>Raised Date:</b> {task.raisedDate}
          </p>

          <p>
            <b>Due Date:</b> {task.dueDate}
          </p>

          <p>
            <b>Status:</b> {task.status}
          </p>

          <button
            onClick={() => setEditMode(true)}
          >
            Edit
          </button>

          <button
            className="delete"
            onClick={removeTask}
          >
            Delete
          </button>

        </div>

      )}

    </div>
  );
}

export default TaskDetails;