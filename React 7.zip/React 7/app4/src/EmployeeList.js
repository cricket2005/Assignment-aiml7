import React from "react";
import EmployeeCard from "./EmployeeCard";

function EmployeeList({
  employees,
  editEmployee,
  deleteEmployee
}) {

  return (

    <div className="employee-list">

      <h2>Employee List</h2>

      {employees.length === 0 ? (

        <p className="no-data">
          No employees found.
        </p>

      ) : (

        <div className="cards">

          {employees.map((employee) => (

            <EmployeeCard
              key={employee.id}
              employee={employee}
              editEmployee={editEmployee}
              deleteEmployee={deleteEmployee}
            />

          ))}

        </div>

      )}

    </div>
  );
}

export default EmployeeList;