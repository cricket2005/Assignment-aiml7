import React from "react";
import { Link, useNavigate } from "react-router-dom";

function Navbar({ isLoggedIn, setIsLoggedIn }) {

  const navigate = useNavigate();

  const logout = () => {
    setIsLoggedIn(false);
    navigate("/dashboard");
  };

  return (
    <nav className="navbar">

      <h2>Task Manager</h2>

      <div className="nav-links">

        <Link to="/dashboard">
          Dashboard
        </Link>

        <Link to="/tasks">
          Tasks
        </Link>

        <Link to="/add-task">
          Add Task
        </Link>

        <Link to="/completed">
          Completed
        </Link>

        {isLoggedIn && (
          <button onClick={logout}>
            Logout
          </button>
        )}

      </div>

    </nav>
  );
}

export default Navbar;